<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  <style>
.mx-n {
  margin-left: -0.75rem !important;
  margin-right: -0.75rem !important;
}
.items {
    margin-left:10px;
}
  </style>
  </head>
  <body>

    <div class="container-fluid text-center">
     <div class="row">
      <div class="col-2 bg-body-tertiary">
       <div class="mt-3 px-auto">
        <a href="<?php echo e(url('/test')); ?>" class="brand-link">
         <img src="/back/dist/assets/img/logo12_1.png" alt="urbanhomes Logo" class="brand-image opacity-75 " />
        </a>
       </div>
       <div class="container">
       <ul class="list-unstyled m-3 pl-3">
        <li class="nav-item ml-3">
            <a href="#" class="nav-link d-flex flex-row p-2">
                <div class="">
                    <img src="/back/dist/assets/img/dashboard.png" alt="" class="" />
                </div>
                <div class="items">
                    <p>Dashboard</p>
                </div>
            </a>
        </li>
        <li class="nav-item ml-3">
            <a href="#" class="nav-link pb-2 d-flex flex-row text-center">
                <div class="pr-2">
                    <img src="/back/dist/assets/img/payments-outline.png" alt="" class="brand-image opacity-75 " />
                </div>
                <div class="items">
                    <p>Rent</p>
                </div>
            </a>
        </li>
        <li class="nav-item ml-3">
            <a href="#" class="nav-link pb-2 d-flex flex-row text-center">
                <div class="pr-2">
                    <img src="/back/dist/assets/img/request.png" alt="" class="" />
                </div>
                <div class="items">
                    <p>Request</p>
                </div>
        </li>
        <li class="nav-item ml-3">
            <a href="#" class="nav-link pb-2 d-flex flex-row text-center">
                <div class="mr-2">
                    <img src="/back/dist/assets/img/uil_setting.png" alt="" class="" />
                </div>
                <div class="items" style="">
                    <p>Profile Settings</p>
                </div>
            </a>
        </li>
        <li class="nav-item" style="margin-top:400px;">
            <a href="#" class="nav-link">
            <img src="/back/dist/assets/img/logout.png" alt="" class="brand-image opacity-75" />
            <p>Logout</p>
            </a>
        </li>
       </ul>
       </div>
      </div>
      <div class="col-10">
        <nav class="navbar navbar-expand bg-body-tertiary mx-n px-0">
            <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                <li class="nav-item">
                <a class="nav-link" href="#" role="button">
                    <img src="/back/dist/assets/img/home.png" alt="homw Logo" class="" />
                </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">
                        <img src="/back/dist/assets/img/message.png" alt="" class="" />
                    </a>
                </li>
                <li class="nav-item">
                <a class="nav-link" href="#">
                    <img src="/back/dist/assets/img/alarm.png" alt="" class="" />
                </a>
                </li>
                <li class="nav-item">
                <a href="#" class="nav-link">
                    <img src="/back/dist/assets/img/user.png" alt="homw Logo" class="" />
                </a>
                </li>            
            </ul>
        </nav>
      </div>
     </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
  </body>
</html><?php /**PATH C:\Users\USER\Documents\Alfa Daud Project\urbanhomes\resources\views/home_new.blade.php ENDPATH**/ ?>