<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?php echo $__env->yieldContent('pageTitle'); ?></title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">

<style>
/* * {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  font-family: system-ui, -apple-system, sans-serif;
}

.header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 1rem 5%;
  border-bottom: 1px solid #eee;
}

.logo {
  height: 40px;
}

.auth-link {
  display: flex;
  align-items: center;
  gap: 1rem;
  text-decoration: none;
}

.sign-in {
  background: #5754e8;
  color: white;
  padding: 0.5rem 1.5rem;
  border-radius: 0.5rem;
  text-decoration: none;
}

.account-section {
  max-width: 1200px;
  margin: 4rem auto;
  padding: 0 1rem;
  text-align: center;
}

.section-title {
  font-size: 2rem;
  margin-bottom: 1rem;
  color: #333;
}

.section-subtitle {
  color: #666;
  margin-bottom: 3rem;
}

.cards-container {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 2rem;
  margin-bottom: 3rem;
}

.account-card {
  padding: 2rem;
  border-radius: 1rem;
  background: white;
  box-shadow: 0 2px 10px rgba(0,0,0,0.05);
  cursor: pointer;
  transition: transform 0.2s;
}

.account-card:hover {
  transform: translateY(-5px);
}

.icon-circle {
  width: 64px;
  height: 64px;
  background: #f0f0ff;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  margin: 0 auto 1rem;
}

.account-type {
  color: #666;
  margin-top: 0.5rem;
}

.free-tag {
  color: #666;
  margin-bottom: 1rem;
}

.trial-tag {
  background: #5754e8;
  color: white;
  padding: 0.5rem 1rem;
  border-radius: 1rem;
  display: inline-block;
  margin-bottom: 1rem;
}

.contact-tag {
  background: #5754e8;
  color: white;
  padding: 0.5rem 1rem;
  border-radius: 1rem;
  display: inline-block;
  margin-bottom: 1rem;
}

.select-button {
  background: #5754e8;
  color: white;
  padding: 0.75rem 2rem;
  border: none;
  border-radius: 0.5rem;
  cursor: pointer;
  font-size: 1rem;
}

.select-button:hover {
  background: #4744d8;
} */

 
.bcp {
    background: #524CBF;
  }

  .tcp {
    color: #524CBF;
  }
  .tc{
    color: #626262;
  }

  .mp{
    margin: 0;
    padding: 0;
  }
</style>
</head>
<body>

  
  <nav class="navbar bg-white shadow-sm">
    <div class="container-fluid d-flex justify-content-between" style="margin-left: 100px; margin-right: 100px;">
      <a href="/" class="logo">
          <img src="/home/images/homes_logo.png" alt="UrbanHomes.ng Logo">
      </a>
      <div class="auth-link d-flex justify-content-between">
        <h5 class="tcp text-center my-auto" style="margin-right: 20px;">Already have an account?</h5>
        <a href="#" class="btn btn bcp px-4 text-white" ><h5>Sign In</h5></a>
      </div>
    </div>
  </nav>

  <section>
    <div class="text-center py-5">
      <h1 class="section-title text-center" style="color: #343A40;">Account Type</h1>
      <h4 class="tc">Choose the user account type that suits your needs.</h4>
    </div>

    <div class="container-fluid ">

      <div class="row" style="margin-left: 150px; margin-right: 150px;">
        <div class="col-sm-3 mb-3 mb-sm-0">
          <div class="card text-center shadow-lg">
            <div class="card-body">
              <h5 class="card-title tc mt-3 mb-4">Free account</h5>
              <div class="bcp text-center mx-auto" style="width: 50px; height:50px; border-radius:50%;">
                  <img src="/home/images/fluent_person-home-16-filled.png" style="margin-top:10px;" class="" alt="">
              </div>
              <h3 class="card-text tc">I'm renting</h3>
              <p class="tc" style="font-size: 20px;">Tenant</p>
            </div>
          </div>
        </div>
        <div class="col-sm-3 mb-3 mb-sm-0">
          <div class="card text-center shadow-lg">
            <div class="card-body">
              <h5 class="card-title tc mt-3 mb-4">Free account</h5>
              <div class="bcp text-center tc mx-auto rounded-5" style="width: 50px; height:50px;">
                <img src="/home/images/flowbite_fix-tables-outline.png" style="margin-top:10px;" alt="">
              </div>
              <h3 class="card-text tc">I fix rentals</h3>
              <p class="tc" style="font-size: 20px;">Service professional</p>
            </div>
          </div>
        </div>
        <div class="col-sm-3 mb-3 mb-sm-0">
          <div class="card text-center shadow-lg">
            <div class="card-body">
              <h5 class="card-title bcp text-white rounded py-1 mt-3 mb-4">Free 14-day trial</h5>
              <div class="bcp text-center mx-auto rounded-5" style="width: 50px; height:50px;">
                <img src="/home/images/tabler_briefcase.png" style="margin-top:10px;" alt="">
              </div>
              <h3 class="card-text tc">I manage rentals</h3>
              <p class="tc" style="font-size: 20px;">Property manager</p>
            </div>
          </div>
        </div>
        <div class="col-sm-3 mb-3 mb-sm-0">
          <div class="card text-center shadow-lg">
            <div class="card-body">
              <h5 class="card-title bcp text-white rounded p-1 mt-3 mb-4">Contact your property manager</h5>
              <div class="bcp text-center mx-auto rounded-5" style="width: 50px; height:50px;">
                <img src="/home/images/emojione-monotone_old-man.png" style="margin-top:10px;" alt="">
              </div>
              <h3 class="card-text tc">I'm a property owner</h3>
              <p class="tc" style="font-size: 20px;">Landlord</p>
            </div>
          </div>
        </div>
      </div>
      <div class="text-center" style="margin-top: 100px;">
        <a href="#" class="btn btn bcp px-4 py-2 text-white text-center" style=""><h5 class="my-auto">Select</h5></a>

      </div>

    </div>

    <button class="select-button"></button>
  </section>
</body>
</html><?php /**PATH C:\Users\USER\Documents\Alfa Daud Project\urbanhomes\resources\views/home/page2.blade.php ENDPATH**/ ?>