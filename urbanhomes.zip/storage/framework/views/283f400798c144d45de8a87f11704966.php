<!DOCTYPE html>
<html lang="en">
<head>
<style>
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  font-family: system-ui, -apple-system, sans-serif;
}

.header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 1rem 5%;
  border-bottom: 1px solid #eee;
}

.logo {
  height: 40px;
}

.auth-link {
  display: flex;
  align-items: center;
  gap: 1rem;
  text-decoration: none;
}

.sign-in {
  background: #5754e8;
  color: white;
  padding: 0.5rem 1.5rem;
  border-radius: 0.5rem;
  text-decoration: none;
}

.account-section {
  max-width: 1200px;
  margin: 4rem auto;
  padding: 0 1rem;
  text-align: center;
}

.section-title {
  font-size: 2rem;
  margin-bottom: 1rem;
  color: #333;
}

.section-subtitle {
  color: #666;
  margin-bottom: 3rem;
}

.cards-container {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 2rem;
  margin-bottom: 3rem;
}

.account-card {
  padding: 2rem;
  border-radius: 1rem;
  background: white;
  box-shadow: 0 2px 10px rgba(0,0,0,0.05);
  cursor: pointer;
  transition: transform 0.2s;
}

.account-card:hover {
  transform: translateY(-5px);
}

.icon-circle {
  width: 64px;
  height: 64px;
  background: #f0f0ff;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  margin: 0 auto 1rem;
}

.account-type {
  color: #666;
  margin-top: 0.5rem;
}

.free-tag {
  color: #666;
  margin-bottom: 1rem;
}

.trial-tag {
  background: #5754e8;
  color: white;
  padding: 0.5rem 1rem;
  border-radius: 1rem;
  display: inline-block;
  margin-bottom: 1rem;
}

.contact-tag {
  background: #5754e8;
  color: white;
  padding: 0.5rem 1rem;
  border-radius: 1rem;
  display: inline-block;
  margin-bottom: 1rem;
}

.select-button {
  background: #5754e8;
  color: white;
  padding: 0.75rem 2rem;
  border: none;
  border-radius: 0.5rem;
  cursor: pointer;
  font-size: 1rem;
}

.select-button:hover {
  background: #4744d8;
}
</style>
</head>
<body>
  <header class="header">
    <img src="/api/placeholder/180/40" alt="Urban Homes Logo" class="logo">
    <div class="auth-link">
      <span>Already have an account?</span>
      <a href="#" class="sign-in">Sign In</a>
    </div>
  </header>

  <section class="account-section">
    <h1 class="section-title">Account Type</h1>
    <p class="section-subtitle">Choose the user account type that suits your needs.</p>

    <div class="cards-container">
      <div class="account-card">
        <div class="free-tag">Free account</div>
        <div class="icon-circle">👤</div>
        <h2>I'm renting</h2>
        <p class="account-type">Tenant</p>
      </div>

      <div class="account-card">
        <div class="free-tag">Free account</div>
        <div class="icon-circle">🔧</div>
        <h2>I fix rentals</h2>
        <p class="account-type">Service professional</p>
      </div>

      <div class="account-card">
        <div class="trial-tag">Free 14-day trial</div>
        <div class="icon-circle">💼</div>
        <h2>I manage rentals</h2>
        <p class="account-type">Property manager</p>
      </div>

      <div class="account-card">
        <div class="contact-tag">Contact your property manager</div>
        <div class="icon-circle">🏠</div>
        <h2>I'm a property owner</h2>
        <p class="account-type">Landlord</p>
      </div>
    </div>

    <button class="select-button">Select</button>
  </section>
</body>
</html><?php /**PATH C:\Users\USER\Documents\Alfa Daud Project\urbanhomes\resources\views/page3.blade.php ENDPATH**/ ?>