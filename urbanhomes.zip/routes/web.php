<?php

use Illuminate\Support\Facades\Route;

// Route::get('/', function () {
//     return view('welcome');
// });

Route::view('/', 'home.home');
Route::view('/page2', 'home.page2');
Route::view('/page3', 'home.page3');
Route::view('/page4', 'back.page4');
Route::view('/page5', 'home.page5');
Route::view('/page6', 'back.page6');
Route::view('/page7', 'home.page7');
Route::view('/page8', 'back.page8');
Route::view('/page9', 'home.page9');
Route::view('/page10', 'back.page10');
Route::view('/page11', 'home.page11');
Route::view('/page12', 'back.page12');
Route::view('/page13', 'back.page13');
Route::view('/page14', 'home.page14');
Route::view('/page15', 'home.page15');
Route::view('/page16', 'home.page16');
Route::view('/page17', 'back.page17');