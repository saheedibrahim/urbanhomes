
<?php $__env->startSection('pageTitle', 'Page 10'); ?>
<?php $__env->startSection('content'); ?>
    <div class="mt-5 pt-5" style="margin-left:100px; margin-right:150px;">
        <div class="mb-4">
            <h5><a href="">Go back to sign up</a></h5>
        </div>
        <div class="my-5 pt-5">
            <h2>Email Verified</h2>
            <p class="mp">Your email has been successfully verified.</p>
            <p>Click below to continue with your account setup.</p>
        </div>
        <div class="text-center mx-4 my-5">
            <p><a href="" class="btn btn w-100" style="background: #524CBF;">Continue</a></p>
            <p>Go back to <a href="">Login</a></p>
            
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('home.layout.auth-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Documents\Alfa Daud Project\urbanhomes\resources\views/home/page10.blade.php ENDPATH**/ ?>