
<?php $__env->startSection('pageTitle', 'Page 12'); ?>

<?php $__env->startSection('content'); ?>      
<div class="mx-auto text-center bg-white">
    <div>
        <h2 class="tc one">Congratulations!</h2>
    </div>
    <div class="">
        <img src="/back/dist/assets/img/image22.png" alt="">
        <p style="color: #626262;">You have created a new maintenance request.</p>
        <h5 style="color: #626262;">#000001 for Ajetumobi House</h5>
        <h6 class="mb-3 mt-5"><a href="" class="" style="color: #524CBF;">back to Dashboard</a></h6>
        <a href="" class="btn text-white px-4" style="background: #524CBF;"><h6 class="my-auto">View  Request</h6></a>
    </div>
</div> 
   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('back.layout.pages-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Documents\Alfa Daud Project\urbanhomes\resources\views/back/page12.blade.php ENDPATH**/ ?>