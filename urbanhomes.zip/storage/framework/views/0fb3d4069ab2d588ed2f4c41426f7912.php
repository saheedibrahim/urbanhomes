<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Choose Account Type - UrbanHomes.ng</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Arial', sans-serif;
        }

        :root {
            --primary-color: #5648ED;
            --text-dark: #333333;
            --text-light: #666666;
            --background-light: #f8f9fa;
        }

        body {
            min-height: 100vh;
            background-color: var(--background-light);
        }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 1rem 5%;
            background: white;
            box-shadow: 0 2px 4px rgba(0,0,0,0.05);
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            text-decoration: none;
        }

        .logo img {
            height: 40px;
        }

        .auth-section {
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .auth-text {
            color: var(--text-light);
        }

        .sign-in-btn {
            background-color: var(--primary-color);
            color: white;
            padding: 0.5rem 1.5rem;
            border-radius: 4px;
            text-decoration: none;
            font-weight: 500;
        }

        .main-content {
            max-width: 1200px;
            margin: 4rem auto;
            padding: 0 1rem;
            text-align: center;
        }

        h1 {
            color: var(--text-dark);
            font-size: 2rem;
            margin-bottom: 1rem;
        }

        .subtitle {
            color: var(--text-light);
            margin-bottom: 3rem;
        }

        .account-types {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 2rem;
            margin-bottom: 3rem;
        }

        .account-card {
            background: white;
            border-radius: 8px;
            padding: 2rem;
            text-align: center;
            cursor: pointer;
            transition: transform 0.2s, box-shadow 0.2s;
            position: relative;
        }

        .account-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }

        .account-icon {
            width: 60px;
            height: 60px;
            background-color: var(--primary-color);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 1.5rem;
        }

        .account-icon svg {
            width: 30px;
            height: 30px;
            fill: white;
        }

        .account-title {
            color: var(--text-dark);
            font-size: 1.25rem;
            margin-bottom: 0.5rem;
        }

        .account-subtitle {
            color: var(--text-light);
        }

        .account-badge {
            position: absolute;
            top: 1rem;
            right: 1rem;
            background-color: var(--primary-color);
            color: white;
            padding: 0.25rem 0.75rem;
            border-radius: 20px;
            font-size: 0.875rem;
        }

        .select-btn {
            background-color: var(--primary-color);
            color: white;
            padding: 0.75rem 3rem;
            border-radius: 4px;
            border: none;
            font-size: 1rem;
            cursor: pointer;
            transition: background-color 0.2s;
        }

        .select-btn:hover {
            background-color: #4538d0;
        }

        @media (max-width: 768px) {
            .account-types {
                grid-template-columns: 1fr;
                gap: 1rem;
            }

            .header {
                padding: 1rem;
            }

            .auth-text {
                display: none;
            }
        }
    </style>
</head>
<body>
    <header class="header">
        <a href="/" class="logo">
            <img src="/api/placeholder/40/40" alt="UrbanHomes.ng Logo">
        </a>
        <div class="auth-section">
            <span class="auth-text">Already have an account?</span>
            <a href="/signin" class="sign-in-btn">Sign In</a>
        </div>
    </header>

    <main class="main-content">
        <h1>Account Type</h1>
        <p class="subtitle">Choose the user account type that suits your needs.</p>

        <div class="account-types">
            <div class="account-card">
                <div class="account-icon">
                    <svg viewBox="0 0 24 24">
                        <path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/>
                    </svg>
                </div>
                <h3 class="account-title">I'm renting</h3>
                <p class="account-subtitle">Tenant</p>
                <span class="account-badge">Free account</span>
            </div>

            <div class="account-card">
                <div class="account-icon">
                    <svg viewBox="0 0 24 24">
                        <path d="M21.67 18.17l-5.3-5.3h-.99l-2.54 2.54v.99l5.3 5.3c.39.39 1.02.39 1.41 0l2.12-2.12c.39-.38.39-1.02 0-1.41z"/>
                    </svg>
                </div>
                <h3 class="account-title">I fix rentals</h3>
                <p class="account-subtitle">Service professional</p>
                <span class="account-badge">Free account</span>
            </div>

            <div class="account-card">
                <div class="account-icon">
                    <svg viewBox="0 0 24 24">
                        <path d="M20 6h-4V4c0-1.11-.89-2-2-2h-4c-1.11 0-2 .89-2 2v2H4c-1.11 0-1.99.89-1.99 2L2 19c0 1.11.89 2 2 2h16c1.11 0 2-.89 2-2V8c0-1.11-.89-2-2-2zm-6 0h-4V4h4v2z"/>
                    </svg>
                </div>
                <h3 class="account-title">I manage rentals</h3>
                <p class="account-subtitle">Property manager</p>
                <span class="account-badge">Free 14-day trial</span>
            </div>

            <div class="account-card">
                <div class="account-icon">
                    <svg viewBox="0 0 24 24">
                        <path d="M12 7V3H2v18h20V7H12zM6 19H4v-2h2v2zm0-4H4v-2h2v2zm0-4H4V9h2v2zm0-4H4V5h2v2zm4 12H8v-2h2v2zm0-4H8v-2h2v2zm0-4H8V9h2v2zm0-4H8V5h2v2zm10 12h-8v-2h2v-2h-2v-2h2v-2h-2V9h8v10zm-2-8h-2v2h2v-2zm0 4h-2v2h2v-2z"/>
                    </svg>
                </div>
                <h3 class="account-title">I'm a property owner</h3>
                <p class="account-subtitle">Landlord</p>
                <span class="account-badge">Contact your property manager</span>
            </div>
        </div>

        <button class="select-btn">Select</button>
    </main>
</body>
</html><?php /**PATH C:\Users\USER\Documents\Alfa Daud Project\urbanhomes\resources\views/page2.blade.php ENDPATH**/ ?>