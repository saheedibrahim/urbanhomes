<!DOCTYPE html>
<html lang="en">
<head>
<style>
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  font-family: system-ui, -apple-system, sans-serif;
}

.login-container {
  display: flex;
  min-height: 100vh;
}

.left-panel {
  flex: 1;
  background: #5754e8;
  padding: 3rem;
  color: white;
  display: flex;
  flex-direction: column;
  justify-content: center;
}

.left-panel h1 {
  font-size: 3rem;
  margin-bottom: 2rem;
}

.illustration {
  max-width: 80%;
}

.right-panel {
  flex: 1;
  padding: 3rem;
  background: white;
  display: flex;
  flex-direction: column;
  justify-content: center;
}

.logo {
  height: 40px;
  margin-bottom: 2rem;
}

.welcome-text {
  margin-bottom: 0.5rem;
  font-size: 2rem;
}

.subtitle {
  color: #666;
  margin-bottom: 2rem;
}

.social-buttons {
  display: flex;
  gap: 1rem;
  margin-bottom: 2rem;
}

.social-button {
  flex: 1;
  padding: 0.75rem;
  border: 1px solid #ddd;
  border-radius: 0.5rem;
  background: white;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 0.5rem;
  cursor: pointer;
}

.divider {
  text-align: center;
  margin: 1.5rem 0;
  color: #666;
}

.form-group {
  margin-bottom: 1.5rem;
}

.form-label {
  display: block;
  margin-bottom: 0.5rem;
  color: #333;
}

.form-input {
  width: 100%;
  padding: 0.75rem;
  border: 1px solid #ddd;
  border-radius: 0.5rem;
  font-size: 1rem;
}

.forgot-password {
  text-align: right;
  margin-bottom: 1.5rem;
}

.forgot-password a {
  color: #5754e8;
  text-decoration: none;
}

.login-button {
  width: 100%;
  padding: 0.75rem;
  background: #5754e8;
  color: white;
  border: none;
  border-radius: 0.5rem;
  font-size: 1rem;
  cursor: pointer;
}

.signup-prompt {
  text-align: center;
  margin-top: 2rem;
  color: #666;
}

.signup-prompt a {
  color: #5754e8;
  text-decoration: none;
}

@media (max-width: 768px) {
  .login-container {
    flex-direction: column;
  }
  
  .left-panel {
    padding: 2rem;
  }
  
  .right-panel {
    padding: 2rem;
  }
  
  .social-buttons {
    flex-direction: column;
  }
}
</style>
</head>
<body>
  <div class="login-container">
    <div class="left-panel">
      <h1>Rental management made easy...</h1>
      <img src="/api/placeholder/400/300" alt="Property Management Illustration" class="illustration">
    </div>
    
    <div class="right-panel">
      <img src="/api/placeholder/180/40" alt="Urban Homes Logo" class="logo">
      <h2 class="welcome-text">Welcome back</h2>
      <p class="subtitle">Log into your account</p>
      
      <div class="social-buttons">
        <button class="social-button">
          <img src="/api/placeholder/20/20" alt="Google Logo">
          Sign in with Google
        </button>
        <button class="social-button">
          <img src="/api/placeholder/20/20" alt="Facebook Logo">
          Sign in with Facebook
        </button>
      </div>
      
      <div class="divider">— OR —</div>
      
      <form>
        <div class="form-group">
          <label class="form-label">Email Address or Username</label>
          <input type="text" class="form-input" placeholder="example@mail.com or adewale">
        </div>
        
        <div class="form-group">
          <label class="form-label">Password</label>
          <input type="password" class="form-input" placeholder="********">
        </div>
        
        <div class="forgot-password">
          <a href="#">Forgot Password?</a>
        </div>
        
        <button class="login-button">Login</button>
      </form>
      
      <div class="signup-prompt">
        Don't have a UrbanHomes.ng account? <a href="#">Create One</a>
      </div>
    </div>
  </div>
</body>
</html><?php /**PATH C:\Users\USER\Documents\Alfa Daud Project\urbanhomes\resources\views/page2x.blade.php ENDPATH**/ ?>