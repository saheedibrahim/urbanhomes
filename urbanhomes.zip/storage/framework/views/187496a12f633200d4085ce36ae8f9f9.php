<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>UrbanHomes.ng - Rental Management</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .login-container {
            min-height: 100vh;
            background-color: #4834d4;
        }
        .illustration {
            max-width: 400px;
            margin: auto;
        }
        .login-card {
            background: white;
            border-radius: 20px;
            padding: 2rem;
            max-width: 500px;
        }
        .social-btn {
            border: 1px solid #ddd;
            padding: 0.5rem;
            border-radius: 5px;
            width: 100%;
            text-align: center;
            margin-bottom: 1rem;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
        }
        .google-btn {
            background-color: white;
            color: #333;
        }
        .facebook-btn {
            background-color: white;
            color: #333;
        }
        .login-btn {
            background-color: #4834d4;
            border: none;
            padding: 0.75rem;
        }
        .or-divider {
            text-align: center;
            position: relative;
            margin: 1.5rem 0;
        }
        .or-divider:before,
        .or-divider:after {
            content: "";
            position: absolute;
            height: 1px;
            width: 45%;
            background-color: #ddd;
            top: 50%;
        }
        .or-divider:before {
            left: 0;
        }
        .or-divider:after {
            right: 0;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6 text-white p-5">
                    <h1 class="mb-4">Rental management made easy...</h1>
                    <div class="illustration">
                        <img src="/api/placeholder/400/300" alt="Rental Management Illustration" class="img-fluid">
                    </div>
                </div>
                <div class="col-lg-6 p-4">
                    <div class="login-card ms-auto">
                        <img src="/api/placeholder/150/50" alt="UrbanHomes.ng Logo" class="mb-4">
                        <h2>Welcome back</h2>
                        <p class="text-muted mb-4">Log into your account</p>
                        
                        <button class="social-btn google-btn">
                            <img src="/api/placeholder/20/20" alt="Google Icon" width="20">
                            Sign in with Google
                        </button>
                        
                        <button class="social-btn facebook-btn">
                            <img src="/api/placeholder/20/20" alt="Facebook Icon" width="20">
                            Sign in with Facebook
                        </button>

                        <div class="or-divider">
                            <span class="bg-white px-2">OR</span>
                        </div>

                        <form>
                            <div class="mb-3">
                                <label class="form-label">Email Address or Username</label>
                                <input type="text" class="form-control" placeholder="example@mail.com or adewale">
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Password</label>
                                <input type="password" class="form-control" placeholder="********">
                            </div>

                            <div class="text-end mb-3">
                                <a href="#" class="text-decoration-none">Forgot Password?</a>
                            </div>

                            <button type="submit" class="btn btn-primary login-btn w-100">Login</button>

                            <div class="text-center mt-3">
                                <span class="text-muted">Don't have a UrbanHomes.ng account?</span>
                                <a href="#" class="text-decoration-none">Create One</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/js/bootstrap.bundle.min.js"></script>
</body>
</html><?php /**PATH C:\Users\USER\Documents\Alfa Daud Project\urbanhomes\resources\views/page4x.blade.php ENDPATH**/ ?>