<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>UrbanHomes.ng - Nigeria's #1 Property Management Platform</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Arial', sans-serif;
        }

        :root {
            --primary-color: #5648ED;
            --text-dark: #333333;
            --text-light: #666666;
        }

        body {
            line-height: 1.6;
        }

        .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 1rem 5%;
            border-bottom: 1px solid #eee;
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            color: var(--primary-color);
            text-decoration: none;
            font-weight: bold;
            font-size: 1.5rem;
        }

        .nav-links {
            display: flex;
            gap: 2rem;
        }

        .nav-links a {
            text-decoration: none;
            color: var(--text-dark);
        }

        .auth-buttons {
            display: flex;
            gap: 1rem;
        }

        .btn {
            padding: 0.5rem 1.5rem;
            border-radius: 4px;
            text-decoration: none;
            font-weight: 500;
        }

        .btn-outline {
            color: var(--primary-color);
            border: 1px solid var(--primary-color);
        }

        .btn-primary {
            background-color: var(--primary-color);
            color: white;
            border: none;
        }

        .hero {
            display: flex;
            justify-content: space-between;
            align-items: center;
            /* padding: 4rem 5%; */
            /* gap: 2rem; */
        }

        .hero-content {
            flex: 1;
            max-width: 600px;
        }

        .tag {
            /* color: var(--primary-color);
            font-weight: 500;
            margin-bottom: 1rem; */
            font-family: Inter;
            color: #524CBF;

            font-size: 16px;
            font-weight: 700;
            line-height: 19.36px;
            text-align: left;
            text-underline-position: from-font;
            text-decoration-skip-ink: none;

        }

        .hero h1 {
            font-size: 3rem;
            line-height: 1.2;
            margin-bottom: 1.5rem;
            color: var(--text-dark);
        }

        .hero p {
            color: var(--text-light);
            margin-bottom: 2rem;
        }

        .email-signup {
            display: flex;
            gap: 1rem;
            margin-bottom: 1rem;
        }

        .email-signup input {
            flex: 1;
            padding: 0.8rem;
            border: 1px solid #ddd;
            border-radius: 4px;
        }

        .trial-text {
            font-size: 0.9rem;
            color: var(--text-light);
        }

        .view-demo {
            color: var(--primary-color);
            text-decoration: none;
            font-weight: 500;
        }

        .hero-image {
            flex: 1;
            max-width: 600px;
        }

        .hero-image img {
            /* width: 100%;
            height: auto;width: 995px; */
            height: 802px;
            top: 9px;
            left: 676px;
            gap: 0px;
            opacity: 0px;

        }

        .news-section {
            text-align: center;
            padding: 2rem 5%;
            background-color: #f8f8f8;
        }

        .news-tag {
            display: inline-block;
            background-color: var(--primary-color);
            color: white;
            padding: 0.5rem 1.5rem;
            border-radius: 20px;
            margin-bottom: 2rem;
        }

        .news-logos {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 3rem;
            flex-wrap: wrap;
        }

        .news-logos img {
            height: 30px;
            object-fit: contain;
            opacity: 0.7;
        }

        .impact-section {
            padding: 4rem 5%;
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 4rem;
        }

        .impact-content {
            flex: 1;
        }

        .impact-content h2 {
            color: var(--primary-color);
            font-size: 2rem;
            margin-bottom: 1.5rem;
        }

        .sdg-goals {
            flex: 1;
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(80px, 1fr));
            gap: 1rem;
        }

        .sdg-goals img {
            width: 100%;
            height: auto;
        }

        .everything {
            font-family: Inter;
            font-size: 60px;
            font-weight: 700;
            line-height: 72.61px;
            text-align: left;
            text-underline-position: from-font;
            text-decoration-skip-ink: none;
        }

        .property {
            color: #626262;
            font-family: Inter;
            font-size: 22px;
            font-weight: 500;
            line-height: 26.63px;
            text-align: left;
            text-underline-position: from-font;
            text-decoration-skip-ink: none;
        }

        .signup {
            width: 117px;
            height: 41px;
            top: 33px;
            left: 1218px;
            gap: 0px;
            border-radius: 5px 0px 0px 0px;
            opacity: 0px;
        }

        .signin {
            font-family: Inter;
            font-size: 16px;
            font-weight: 700;
            line-height: 19.36px;
            text-align: left;
            text-underline-position: from-font;
            text-decoration-skip-ink: none;

        }

        @media (max-width: 768px) {
            .hero {
                flex-direction: column;
                text-align: center;
            }

            .email-signup {
                flex-direction: column;
            }

            .nav-links {
                display: none;
            }

            .impact-section {
                flex-direction: column;
                text-align: center;
            }
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div>
            <a href="/" class="logo">
                <img src="/home/images/logo12_1.png" alt="Modern apartment building illustration">              
            </a>
        </div>
        <div class="nav-links">
            <a href="#features">Features</a>
            <a href="#use-cases">Use Cases</a>
            <a href="#resources">Resources</a>
            <a href="#pricing">Pricing</a>
        </div>
        <div class="auth-buttons">
            <a href="/signin" class="btn btn-outline" class="signin">Sign In</a>
            <a href="/signup" class="btn btn-primary" class="signup">Sign Up</a>
        </div>
    </nav>

    <section class="hero">
        <div class="hero-content">
            <div class="tag">Nigeria's #1 Property Management Platform</div>
            <h1 class="everything">Everything You Need to Manage Your Properties</h1>
            <p class="property">Property management software that helps you list properties, collect payments, and manage your portfolio with ease, all online.</p>
            <div class="email-signup">
                <input type="email" placeholder="Enter your email to get started">
                <button class="btn btn-primary">Start your FREE trial</button>
            </div>
            <div class="trial-text">
                FREE 14 day trial.
                <a href="#" class="view-demo">View Demo ›</a>
            </div>
        </div>
        <div class="hero-image">
            <img src="/home/images/image_2.png" alt="Modern apartment building illustration">
        </div>
    </section>

    <section class="news-section">
        <div class="news-tag">In the news...</div>
        <div class="news-logos">
            <img src="/home/images/image.png" alt="Punch">
            <img src="/home/images/image_3.png" alt="Techpoint">
            <img src="/home/images/image_4.png" alt="The Guardian">
            <img src="/home/images/image_4x.png" alt="TechCabal">
            <img src="/home/images/image_5.png" alt="This Day">
            <img src="/home/images/image_6.png" alt="Legit">
        </div>
    </section>

    <section class="impact-section">
        <div class="impact-content">
            <h2>We Are Committed to Impact</h2>
            <p>Being the first ever digital-technology company in Nigeria & Africa at large to identify with and incorporate the United Nations Sustainable Development Goals.</p>
        </div>
        <div class="sdg-goals">
            <img src="/home/images/image_8.png" alt="SDG Goal 1">
        </div>
    </section>
</body>
</html><?php /**PATH C:\Users\USER\Documents\Alfa Daud Project\urbanhomes\resources\views/homeo.blade.php ENDPATH**/ ?>