<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Urban Homes - Dashboard</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-purple: #5046E4;
            --light-purple: #F5F4FF;
            --overdue-red: #FF4444;
        }
        body {
            background-color: #F8F9FA;
        }
        .sidebar {
            width: 250px;
            height: 100vh;
            position: fixed;
            background: white;
            padding: 1.5rem;
            border-right: 1px solid #eee;
        }
        .main-content {
            margin-left: 250px;
            padding: 2rem;
        }
        .nav-link {
            color: #666;
            padding: 0.75rem 1rem;
            margin: 0.25rem 0;
            border-radius: 8px;
        }
        .nav-link.active {
            background-color: var(--light-purple);
            color: var(--primary-purple);
        }
        .nav-link i {
            width: 20px;
            margin-right: 10px;
        }
        .welcome-card {
            background: var(--light-purple);
            border-radius: 15px;
            padding: 2rem;
            text-align: center;
        }
        .property-card {
            background: white;
            border-radius: 12px;
            padding: 1.5rem;
            border: 1px solid #eee;
        }
        .status-badge {
            background: #E8F5E9;
            color: #2E7D32;
            padding: 0.25rem 1rem;
            border-radius: 20px;
            font-size: 0.875rem;
        }
        .wallet-circle {
            width: 150px;
            height: 150px;
            border-radius: 50%;
            background: var(--light-purple);
            display: flex;
            align-items: center;
            justify-content: center;
            flex-direction: column;
            margin: 1rem auto;
        }
        .table {
            background: white;
            border-radius: 12px;
            overflow: hidden;
        }
        .overdue {
            color: var(--overdue-red);
        }
        .btn-purple {
            background: var(--primary-purple);
            color: white;
        }
        .btn-outline-purple {
            border: 1px solid var(--primary-purple);
            color: var(--primary-purple);
        }
        .header-icons {
            gap: 1rem;
        }
    </style>
</head>
<body>
    <div class="sidebar">
        <img src="/api/placeholder/150/40" alt="Urban Homes Logo" class="mb-4">
        <nav class="nav flex-column">
            <a class="nav-link active" href="#"><i class="fas fa-th-large"></i> Dashboard</a>
            <a class="nav-link" href="#"><i class="fas fa-home"></i> Rent</a>
            <a class="nav-link" href="#"><i class="fas fa-file-alt"></i> Request</a>
            <a class="nav-link" href="#"><i class="fas fa-cog"></i> Profile Settings</a>
            <a class="nav-link mt-auto text-danger" href="#"><i class="fas fa-sign-out-alt"></i> Logout</a>
        </nav>
    </div>

    <div class="main-content">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h2>Hi, Adewale</h2>
                <p class="text-muted">What will you be doing today?</p>
            </div>
            <div class="header-icons d-flex align-items-center">
                <a href="#" class="text-dark"><i class="fas fa-home"></i></a>
                <a href="#" class="text-dark"><i class="fas fa-envelope"></i></a>
                <a href="#" class="text-dark"><i class="fas fa-bell"></i></a>
                <a href="#" class="text-dark"><i class="fas fa-user-circle"></i></a>
            </div>
        </div>

        <div class="row g-4">
            <div class="col-md-4">
                <div class="welcome-card">
                    <img src="/api/placeholder/80/80" alt="House icon" class="mb-3">
                    <h5>Connect with Property</h5>
                    <p class="text-muted">Add your rented apartment to get started using UrbanHomes</p>
                    <button class="btn btn-purple">Get Started</button>
                </div>
            </div>
            <div class="col-md-4">
                <div class="property-card">
                    <div class="d-flex justify-content-between align-items-start mb-3">
                        <div>
                            <small class="text-muted">Oct. 12, 2024 - Oct. 12, 2025</small>
                            <h5 class="mb-0">Ajetunmobi's House</h5>
                        </div>
                        <span class="status-badge">Active</span>
                    </div>
                    <h4 class="mb-3">₦1,500,000 <small class="text-muted">/per annum</small></h4>
                    <hr>
                    <div class="tenant-info">
                        <p class="mb-2"><i class="fas fa-user me-2"></i> Adewale Uchechukwu Aliu</p>
                        <p class="mb-2"><i class="fas fa-door-open me-2"></i> Room 03</p>
                        <p class="mb-0"><i class="fas fa-bed me-2"></i> 2 Bedroom</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="property-card">
                    <h5>Wallet Balance</h5>
                    <div class="wallet-circle">
                        <h3>₦0.00</h3>
                        <button class="btn btn-outline-purple btn-sm">Create Wallet</button>
                    </div>
                    <div class="text-center mt-3">
                        <p class="mb-1">Due</p>
                        <h4 class="text-danger">₦125,000</h4>
                    </div>
                </div>
            </div>
        </div>

        <div class="mt-4">
            <h5>Transactions</h5>
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Status</th>
                            <th>Due Date</th>
                            <th>Property</th>
                            <th>Total/Paid</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td class="overdue">Overdue</td>
                            <td>12 Oct 2024</td>
                            <td>
                                Aje Services<br>
                                <small class="text-muted">Ajetunmobi House, Unit 01</small>
                            </td>
                            <td>₦125,000</td>
                            <td><a href="#" class="text-primary">Details</a></td>
                        </tr>
                        <tr>
                            <td class="overdue">Overdue</td>
                            <td>12 Sept 2024</td>
                            <td>
                                Aje Services<br>
                                <small class="text-muted">Ajetunmobi House, Unit 01</small>
                            </td>
                            <td>₦125,000</td>
                            <td><a href="#" class="text-primary">Details</a></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/js/bootstrap.bundle.min.js"></script>
</body>
</html><?php /**PATH C:\Users\USER\Documents\Alfa Daud Project\urbanhomes\resources\views/page5x.blade.php ENDPATH**/ ?>