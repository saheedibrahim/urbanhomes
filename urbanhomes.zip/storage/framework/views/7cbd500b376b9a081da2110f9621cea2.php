<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Urban Homes - Login</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-purple: #5046E4;
        }
        body {
            background-color: var(--primary-purple);
            min-height: 100vh;
            display: flex;
            align-items: center;
        }
        .brand-logo {
            width: 180px;
            height: auto;
        }
        .login-container {
            background: white;
            border-radius: 20px;
            padding: 2rem;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        .login-illustration {
            max-width: 400px;
            margin-bottom: 2rem;
        }
        .heading-text {
            color: white;
            font-size: 2.5rem;
            font-weight: bold;
            max-width: 400px;
        }
        .btn-google, .btn-facebook {
            border: 1px solid #ddd;
            background: white;
            width: 100%;
            margin-bottom: 0.5rem;
            padding: 0.5rem;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
        }
        .btn-login {
            background-color: var(--primary-purple);
            width: 100%;
            padding: 0.75rem;
            color: white;
        }
        .divider {
            text-align: center;
            margin: 1rem 0;
            color: #666;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-6 mb-4 mb-lg-0">
                <h1 class="heading-text mb-4">Rental management made easy...</h1>
                <img src="/api/placeholder/400/320" alt="Rental Management Illustration" class="login-illustration">
            </div>
            <div class="col-lg-6">
                <div class="login-container">
                    <img src="/api/placeholder/180/40" alt="Urban Homes Logo" class="brand-logo mb-4">
                    <h2 class="h3 mb-2">Welcome back</h2>
                    <p class="text-muted mb-4">Log into your account</p>
                    
                    <button class="btn btn-google mb-2">
                        <img src="/api/placeholder/20/20" alt="Google icon" width="20">
                        Sign in with Google
                    </button>
                    <button class="btn btn-facebook mb-3">
                        <img src="/api/placeholder/20/20" alt="Facebook icon" width="20">
                        Sign in with Facebook
                    </button>

                    <div class="divider">— OR —</div>

                    <form>
                        <div class="mb-3">
                            <label class="form-label">Email Address or Username</label>
                            <input type="text" class="form-control" placeholder="example@mail.com or adewale">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Password</label>
                            <div class="position-relative">
                                <input type="password" class="form-control" placeholder="********">
                                <button type="button" class="btn position-absolute top-50 end-0 translate-middle-y">
                                    <img src="/api/placeholder/20/20" alt="Toggle password visibility" width="20">
                                </button>
                            </div>
                        </div>
                        <div class="text-end mb-3">
                            <a href="#" class="text-decoration-none" style="color: var(--primary-purple)">Forgot Password?</a>
                        </div>
                        <button type="submit" class="btn btn-login mb-3">Login</button>
                        <p class="text-center mb-0">
                            Don't have a UrbanHomes.ng account? 
                            <a href="#" class="text-decoration-none" style="color: var(--primary-purple)">Create One</a>
                        </p>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/js/bootstrap.bundle.min.js"></script>
</body>
</html><?php /**PATH C:\Users\USER\Documents\Alfa Daud Project\urbanhomes\resources\views/page3x.blade.php ENDPATH**/ ?>