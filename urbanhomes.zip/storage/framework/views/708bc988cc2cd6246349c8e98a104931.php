
<?php $__env->startSection('pageTitle', isset($pageTitle) ? $pageTitle : "Admin Dashboard"); ?>
<?php $__env->startSection('content'); ?>
<div class="page-header mt-10">
  <div class="row">
    <div class="col-md-6 col-sm-12">
      <div class="title">
        <h4>Maintenance Request</h4>
      </div>
    </div>
    <div class="col-md-7 text-right" style="text-align:right">
      <a class="btn btn-primary dropdown-toggle" href="#" role="button" data-toggle="dropdown">
        + Add Request
      </a>
    </div>
  </div>
</div>
<div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('back.layout.pages-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Documents\Alfa Daud Project\urbanhomes\resources\views/home.blade.php ENDPATH**/ ?>